﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Corps.Core.Model.GameUtils
{
    public class ScoreHelper
    {

    }
}
