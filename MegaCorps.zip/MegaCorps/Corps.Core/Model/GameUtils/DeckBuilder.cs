﻿using Corps.Core.Model.Cards;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Corps.Core.Model.GameUtils
{
    public static class DeckBuilder
    {
        public static readonly int MaxCards = 6;
        public static void UpdateDeck(List<GameCard> deck,int players)
        {
           
        }
        public static  List<GameCard> GetDeck()
        {
            var Deck= new List<GameCard>();
            return Deck;
        }

    }
}
