﻿namespace Corps.Core
{
    public class Class1
    {

    }
}
