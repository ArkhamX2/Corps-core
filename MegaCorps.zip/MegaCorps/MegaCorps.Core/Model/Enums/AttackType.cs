﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MegaCorps.Core.Model.Enums
{
    public enum AttackType
    {
        Trojan,
        Worm,
        DoS,
        Scripting,
        Botnet,
        Fishing,
        Spy
    }
}
